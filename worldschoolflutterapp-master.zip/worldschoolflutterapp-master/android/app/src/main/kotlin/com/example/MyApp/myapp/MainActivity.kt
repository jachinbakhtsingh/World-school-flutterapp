package com.example.MyApp.myapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
